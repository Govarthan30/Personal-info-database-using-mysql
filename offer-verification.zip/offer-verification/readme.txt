key value for postman
key=text
value=*123*OFFER123*OFFER124#